package Model;

import java.util.ArrayList;
import java.util.List;

public class Carrinho {
    int id;
    List<Produto> produtos = new ArrayList<Produto>();
    Usuario usuario;
    
}
